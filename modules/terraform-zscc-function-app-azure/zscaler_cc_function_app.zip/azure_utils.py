from urllib.parse import urlparse
from datetime import timedelta

from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.mgmt.compute import ComputeManagementClient, models
from azure.monitor.query import MetricsQueryClient, MetricAggregationType

from lib.zs_logger import zslogger
from constants import (
    CC_AGGR_HEALTH_METRIC_NAME,
    CC_METRIC_NAMESPACE
)


def generate_instance_resource_id(subscription, resource_group, instance_id):
    return f"/subscriptions/{subscription}/resourceGroups/{resource_group}/providers/" \
           f"Microsoft.Compute/virtualMachines/{instance_id}"


def generate_ec_group_name(vnet_name, resource_group, subscription, location, vmss_name):
    return f"{vnet_name}-{resource_group}-{subscription}-{location}-{vmss_name}"


def extract_base_url(cc_url):
    prov_url = "https://" + cc_url
    parsed_url = urlparse(prov_url)
    return "https://" + parsed_url.netloc


def vmss_config_extract_vnet_name(vmss_config):
    temp = vmss_config.virtual_machine_profile.network_profile.network_interface_configurations[0]
    subnet = temp.ip_configurations[0].subnet.id
    return subnet.split('/')[-3]


def extract_vmss_name(resource_id):
    return resource_id.split("/")[8]


class AzureClient:
    def __init__(self, subscription_id, managed_identity):
        self.subscription_id = subscription_id
        self.managed_identity = managed_identity
        
        self.credentials = None
        self.compute_mgmt_client = None
        self.secret_client = None
        self.metrics_query_client = None


    @classmethod
    def create_azure_client_instance(cls, subscription_id, managed_identity):
        return cls(subscription_id, managed_identity)


    def init_default_azure_credential(self, ):
        if self.credentials is None:
            self.credentials = DefaultAzureCredential(managed_identity_client_id=self.managed_identity)
            zslogger.info(f"Initialized Azure Credentials.")


    def init_compute_mgmt_client(self, ):
        if self.compute_mgmt_client is None:
            self.compute_mgmt_client = ComputeManagementClient(
                credential=self.credentials,
                subscription_id=self.subscription_id
            )
            zslogger.info(f"Initialized Compute Management Client.")


    def init_secret_client(self, vault_url):
        """
        When initializing Azure Secret Client, it is required the VAULT URL ENV Variable is set.
        """
        if self.secret_client is None:
            if vault_url is None:
                raise Exception(
                    "VAULT_URL is not defined as an App Settings for the Function App. Not able to retrieve "
                    "secrets to perform operations."
                )
            self.secret_client = SecretClient(vault_url=vault_url, credential=self.credentials)
            zslogger.info(f"Initialized Secret Client.")


    def init_metrics_query_client(self, ):
        if self.metrics_query_client is None:
            self.metrics_query_client = MetricsQueryClient(
                credential=self.credentials,
                subscription_id=self.subscription_id
            )
            zslogger.info(f"Initialized Metrics Query Client.")


    def get_secret(self, vault_url, name):
        # init credentials
        self.init_default_azure_credential()
        # init secret client
        self.init_secret_client(vault_url=vault_url)
        # call get secret
        zslogger.info(f"Attempting to get secret {name}.")
        resp = self.secret_client.get_secret(name=name)
        zslogger.info(f"Successfully able to get secret {name}.")
        return resp


    def get_virtual_machine_scale_set(self, resource_group, vmss_name):
        # init credentials
        self.init_default_azure_credential()
        # init compute mgmt client
        self.init_compute_mgmt_client()

        # make call to get vmss config
        zslogger.info(f"Attempting to get VMSS config.")
        response = self.compute_mgmt_client.virtual_machine_scale_sets.get(
            resource_group_name=resource_group,
            vm_scale_set_name=vmss_name,
        )
        zslogger.info(f"Successfully able to get VMSS config.")
        return response


    def update_virtual_machine_scale_set(self, resource_group, vmss_name, vmss_config):
        # init credentials
        self.init_default_azure_credential()

        # init compute mgmt client
        self.init_compute_mgmt_client()

        # make call to update vmss config
        zslogger.info(f"Attempting to update VMSS config.")
        try:
            response = self.compute_mgmt_client.virtual_machine_scale_sets.begin_create_or_update(
                resource_group_name=resource_group,
                vm_scale_set_name=vmss_name,
                parameters=vmss_config
            )
            zslogger.info(f"Successfully able to update VMSS config.")
        except Exception as e:
            zslogger.error(f"Failed to update VMSS Config. Error: {str(e)}")
            raise e
        return response


    def list_vmss_vms(self, resource_group, vmss_name):
        # init credentials
        self.init_default_azure_credential()
        # init compute mgmt client
        self.init_compute_mgmt_client()

        # make call to list vms in vmss
        zslogger.info(f"Attempting to get VMs in VMSS.")
        response = self.compute_mgmt_client.virtual_machine_scale_set_vms.list(
            resource_group_name=resource_group,
            virtual_machine_scale_set_name=vmss_name,
        )
        zslogger.info(f"Successfully able to get VMs in VMSS.")
        return response


    def get_vms_in_vmss(self, resource_group, vmss_name):
        # make call to get VM info for VMs in VMSS
        response = self.list_vmss_vms(resource_group=resource_group, vmss_name=vmss_name)

        # iterate through response and generate list of instance ids
        instance_list = []
        for item in response:
            instance_list.append(item.instance_id)
        return instance_list


    def get_virtual_machine(self, resource_group, instance_id):
        # init credentials
        self.init_default_azure_credential()
        # init compute mgmt client
        self.init_compute_mgmt_client()

        # make call to get VM information
        zslogger.info(f"Attempting to get VM information for instance {instance_id}.")
        response = self.compute_mgmt_client.virtual_machines.get(
            resource_group_name=resource_group,
            vm_name=instance_id
        )
        zslogger.info(f"Successfully able to get VM information for instance {instance_id}.")
        return response


    def list_virtual_machines(self, resource_group):
        # init credentials
        self.init_default_azure_credential()
        # init compute mgmt client
        self.init_compute_mgmt_client()

        # make call to get VM information
        zslogger.info(f"Attempting to list VM information for resource group {resource_group}.")
        response = self.compute_mgmt_client.virtual_machines.list(
            resource_group_name=resource_group,
        )
        zslogger.info(f"Successfully able to list VM information for resource group {resource_group}.")
        return response


    def terminate_virtual_machine(self, resource_group, vmss_name, instance_id):
        # init credentials
        self.init_default_azure_credential()
        # init compute mgmt client
        self.init_compute_mgmt_client()

        # make call to terminate VM
        zslogger.info(f"Attempting to terminate instance {instance_id}.")
        response = self.compute_mgmt_client.virtual_machine_scale_sets.begin_delete_instances(
            resource_group_name=resource_group,
            vm_scale_set_name=vmss_name,
            vm_instance_i_ds=models.VirtualMachineScaleSetVMInstanceRequiredIDs(
                instance_ids=[instance_id]
            )
        )
        zslogger.info(f"Successfully initiated termination of {instance_id}.")
        return response


    def query_resource_metrics(self, resource_id):
        # init credentials
        self.init_default_azure_credential()
        # init metrics query client
        self.init_metrics_query_client()

        # make call to query for metric values
        zslogger.info(f"Attempting to get health metrics for resource {resource_id}.")
        response = self.metrics_query_client.query_resource(
            resource_id,
            metric_names=[CC_AGGR_HEALTH_METRIC_NAME],
            metric_namespace=CC_METRIC_NAMESPACE,
            timespan=timedelta(minutes=30),
            granularity=timedelta(minutes=1),
            aggregations=[MetricAggregationType.MAXIMUM],
        )
        zslogger.info(f"Successfully able to get health metrics for resource {resource_id}.")
        return response

