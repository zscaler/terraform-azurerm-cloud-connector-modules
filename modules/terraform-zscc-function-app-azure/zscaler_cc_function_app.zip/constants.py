CC_AGGR_HEALTH_METRIC_NAME = "cloud_connector_aggr_health"
CC_METRIC_NAMESPACE = "Zscaler/CloudConnectors"
HEALTHY_METRIC_VALUE = 100
UNHEALTHY_METRIC_VALUE = 0
DEFAULT_HC_DATA_POINTS = 10
DEFAULT_HC_UNHEALTHY_THRESHOLD = 7
DEFAULT_HC_CONSECUTIVE_UNHEALTHY_THRESHOLD = 5
DEFAULT_MAX_TERMINATION_PERCENT = 0.2
DEFAULT_GRACE_PERIOD_TIME_MIN = 30

# Real Azure VmIds are always GUIDs (e.g. "f5bbed4f-a3fd-49b5-bfb6-92480b332bcf"). Until a CC
# uploads its cloud-info, Zscaler Cloud reports a placeholder in metaConfig.uuid instead (seen in
# production as "", or "<ecVmId>-4"/"<ecVmId>-6"). Anything that doesn't match this pattern is
# treated as an unresolved placeholder rather than a real VmId.
AZURE_VMID_REGEX = r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
DEFAULT_PLACEHOLDER_UUID_GRACE_PERIOD_MIN = 15

API_KEY_SECRET_NAME = "api-key"
USERNAME_SECRET_NAME = "username"
PASSWORD_SECRET_NAME = "password"

TERMINATION_POLICY_OLDEST = "oldest"
TERMINATION_POLICY_NEWEST = "newest"