from pydantic import BaseModel
import os
import re
import time

from lib.zs_logger import zslogger
from lib.zscaler_client.zscaler_api_client import ZscalerApiClient
from constants import (
    API_KEY_SECRET_NAME,
    USERNAME_SECRET_NAME,
    PASSWORD_SECRET_NAME,
    AZURE_VMID_REGEX,
    DEFAULT_PLACEHOLDER_UUID_GRACE_PERIOD_MIN
)
from azure_utils import AzureClient
from azure_utils import (
    extract_base_url,
    vmss_config_extract_vnet_name,
    generate_ec_group_name,
    extract_vmss_name
)

VAULT_URL = os.environ.get('VAULT_URL')
CC_URL = os.environ.get('CC_URL')

# This module is imported at function app load time, so a bad App Setting value must not raise here
# or the whole function app fails to index. Fall back to the default instead.
_placeholder_grace_period_raw = os.environ.get(
    'PLACEHOLDER_UUID_GRACE_PERIOD_MIN', DEFAULT_PLACEHOLDER_UUID_GRACE_PERIOD_MIN
)
try:
    PLACEHOLDER_UUID_GRACE_PERIOD_MIN = int(_placeholder_grace_period_raw)
    if PLACEHOLDER_UUID_GRACE_PERIOD_MIN < 0:
        raise ValueError("grace period cannot be negative")
except (TypeError, ValueError) as e:
    zslogger.warning(
        f"PLACEHOLDER_UUID_GRACE_PERIOD_MIN App Setting '{_placeholder_grace_period_raw}' is not a valid "
        f"non-negative integer ({str(e)}), falling back to default of "
        f"{DEFAULT_PLACEHOLDER_UUID_GRACE_PERIOD_MIN} min."
    )
    PLACEHOLDER_UUID_GRACE_PERIOD_MIN = DEFAULT_PLACEHOLDER_UUID_GRACE_PERIOD_MIN

AZURE_VMID_PATTERN = re.compile(AZURE_VMID_REGEX)


def is_real_azure_vmid(uuid):
    """
    Returns True if uuid looks like a real Azure VmId (a GUID), as opposed to a placeholder value
    Zscaler Cloud reports before the CC has uploaded its cloud-info (observed in production as ""
    or "<ecVmId>-4"/"<ecVmId>-6", but the exact placeholder format isn't guaranteed, so anything
    that isn't GUID-shaped is treated as unresolved).
    """
    return bool(uuid) and bool(AZURE_VMID_PATTERN.match(uuid))


def get_register_time(item):
    """
    Returns the ecVM's registerTime (unix epoch seconds), or None if unavailable. Zscaler populates
    this shortly after the ecVM slot registers, before its uuid resolves to a real Azure VmId, so
    it's usable as ground truth for how long a slot has been sitting unresolved.
    An ecVM has a single ecInstance in practice; the guards are for missing/partial API data.
    """
    ec_instances = item.get('ecInstances') or []
    if not ec_instances:
        return None
    return ec_instances[0].get('registerTime')


class VMSSInstanceInfo(BaseModel):
    VmId: str
    VmName: str


class ECGroupInstanceInfo(BaseModel):
    VmId: int
    UUID: str
    ECGroupId: int


class ResourceSynchronizer:

    def __init__(self, subscription_id, managed_identity, resource_group, certificate_verify):
        self.subscription_id = subscription_id
        self.managed_identity = managed_identity
        self.resource_group = resource_group
        self.certificate_verify = certificate_verify

        self.azure_client = None
        self.zscaler_client = None

        self.credentials = None
        self.secret_client = None
        self.compute_mgmt_client = None


    @classmethod
    def create_resource_synchronizer_instance(cls, subscription_id, managed_identity, resource_group, certificate_verify):
        return cls(subscription_id, managed_identity, resource_group, certificate_verify)


    def init_azure_client(self, ):
        if self.azure_client is None:
            self.azure_client = AzureClient.create_azure_client_instance(
                subscription_id=self.subscription_id,
                managed_identity=self.managed_identity
            )
            zslogger.info(f"Initialized Azure Client.")


    def get_azure_secrets(self,):
        # init azure client
        self.init_azure_client()

        if VAULT_URL is None:
            raise Exception(
                "VAULT_URL is not defined as an App Settings for the Function App. Not able to retrieve "
                "secrets to perform operations."
            )

        # make call to get api-key secret
        api_key = self.azure_client.get_secret(vault_url=VAULT_URL, name=API_KEY_SECRET_NAME).value
        # make call to get username secret
        username = self.azure_client.get_secret(vault_url=VAULT_URL, name=USERNAME_SECRET_NAME).value
        # make call to get password secret
        password = self.azure_client.get_secret(vault_url=VAULT_URL, name=PASSWORD_SECRET_NAME).value
        return api_key, username, password


    def init_zscaler_client(self, ):
        """
        When initializing Zscaler Client, it is required the CC_URL ENV Variable is set.
        In this function the secrets will be pulled from Azure Key Vaule and initialize the zscaler client.
        """
        if self.zscaler_client is None:
            # generate base url
            if CC_URL is None:
                raise Exception(
                    "CC_URL is not defined as an App Settings for the Function App. Not able to connect to "
                    "Zscaler Cloud."
                )
            api_key, username, password = self.get_azure_secrets()
            self.zscaler_client = ZscalerApiClient(
                api_key=api_key,
                username=username,
                password=password,
                base_url=extract_base_url(cc_url=CC_URL),
                ssl_verify_enable=self.certificate_verify
            )
            zslogger.info(f"Initialized Zscaler Client.")


    def get_vmss_vms(self, vmss_names):
        # init azure client
        self.init_azure_client()

        # init cache of vmss to vm information
        cache = {vmss: [] for vmss in vmss_names}
        
        # list vms in resource group
        vm_resp = self.azure_client.list_virtual_machines(resource_group=self.resource_group)

        # parse list VMs response and organize instances into caches
        for vm in vm_resp:
            if vm.virtual_machine_scale_set is None:
                continue
            
            # extract vmss name and validate instance belongs to known Zscaler CC VMSS
            vmss_name = extract_vmss_name(resource_id=vm.virtual_machine_scale_set.id)
            if vmss_name not in cache:
                zslogger.info(f"VM {vm.name} belongs to vmss {vmss_name} which is not listed as a Zscaler CC VMSS, skipping...")
                continue

            # organize VM into cache
            cache[vmss_name].append(VMSSInstanceInfo(VmId=vm.vm_id, VmName=vm.name))
        return cache


    def get_ec_group_vms(self, vmss_name):
        """
        Function will initialize a zscaler client using secrets stored in Azure Key Vault. It will then 
        make a list EC Groups call to Zscaler Cloud with query parameter of name=<ec-group-name>. It will 
        then parse the response to return a list of dictionaries containing the VM ID and Cloud Native ID. 

        Instances whose uuid hasn't resolved to a real Azure VmId yet are not included in the returned
        instances list (so they're never falsely flagged stale by find_stale_ec_group_instances). They're
        tracked separately: if still unresolved after PLACEHOLDER_UUID_GRACE_PERIOD_MIN (based on the
        ecVM's own registerTime), they're returned as placeholder_stale_instances so the caller can clean
        them up too.
        """
        # init zscaler client
        self.init_zscaler_client()
        # init azure client
        self.init_azure_client()

        # get vmss config to know location and VNet, this will be used for generating ec group name
        vmss_config = self.azure_client.get_virtual_machine_scale_set(
            resource_group=self.resource_group,
            vmss_name=vmss_name
        )

        # generate ec group name
        ec_group_name = generate_ec_group_name(
            vnet_name=vmss_config_extract_vnet_name(vmss_config),
            resource_group=self.resource_group,
            subscription=self.subscription_id,
            location=vmss_config.location,
            vmss_name=vmss_name
        )
        zslogger.info(f"Generated EC Group Name: {ec_group_name}")

        # query EC Group to get list of instances
        zslogger.info(f"Attempting to query EC Group to get list of instances.")
        response = self.zscaler_client.get_ec_group_by_name(ec_group_name=ec_group_name)
        zslogger.info(f"Successfully queried EC Group to get list of instances.")

        if len(response) == 0:
            zslogger.error(f"EC Group {ec_group_name} does not exist.")
            return [], []

        # set ec group ID for use in other functions
        ec_group_id = response[0]['id']

        # parse response to extract mapping of VM Id to Cloud Native Id
        instances = []
        placeholder_stale_instances = []
        now = time.time()
        for item in response[0].get('ecVMs', ''):
            uuid = item['metaConfig'].get('uuid', "")

            if is_real_azure_vmid(uuid):
                instances.append(ECGroupInstanceInfo(
                    VmId=item['id'],
                    UUID=uuid,
                    ECGroupId=ec_group_id
                ))
                continue

            # uuid hasn't resolved to a real Azure VmId yet (e.g. "", "<id>-4", "<id>-6", or any
            # other placeholder format). Use the ecVM's own registerTime as ground truth for age,
            # instead of immediately treating it as stale.
            register_time = get_register_time(item)
            if register_time is None:
                zslogger.warning(
                    f"Instance {item['id']} has unresolved uuid '{uuid}' and no registerTime "
                    f"available, skipping this cycle."
                )
                continue

            age_min = (now - register_time) / 60
            if age_min <= PLACEHOLDER_UUID_GRACE_PERIOD_MIN:
                zslogger.info(
                    f"Instance {item['id']} has unresolved uuid '{uuid}', age {age_min:.1f} min, "
                    f"within {PLACEHOLDER_UUID_GRACE_PERIOD_MIN} min grace period, skipping."
                )
                continue

            zslogger.warning(
                f"Instance {item['id']} has unresolved uuid '{uuid}' for {age_min:.1f} min "
                f"(exceeded {PLACEHOLDER_UUID_GRACE_PERIOD_MIN} min grace period). Azure never "
                f"reported a real VmId for this instance, marking as stale for clean up."
            )
            placeholder_stale_instances.append(ECGroupInstanceInfo(
                VmId=item['id'],
                UUID=uuid,
                ECGroupId=ec_group_id
            ))

        zslogger.info(f"Identified the following instances in EC Group: {instances}")
        if placeholder_stale_instances:
            zslogger.warning(
                f"Identified the following instances with an unresolved uuid past the grace "
                f"period in EC Group: {placeholder_stale_instances}"
            )
        return instances, placeholder_stale_instances


    def find_stale_ec_group_instances(self, ec_group_instances, vmss_instances):
        """
        Function records any instances that exist in the ec_group_instances list but not in the vmss_instances 
        list.
        """
        stale_instances_list = []
        for ec_group_instance in ec_group_instances:
            found = False
            for vmss_instance in vmss_instances:
                if vmss_instance.VmId == ec_group_instance.UUID:
                    found = True
                    break
            if not found:
                stale_instances_list.append(ec_group_instance)
        zslogger.info(f"Identified the following stale instances in the EC Group: {stale_instances_list}")
        return stale_instances_list


    def clean_up_stale_instances(self, stale_instances):
        """
        Function iterates through the passed in stale instances and makes API calls to remove them from EC Group.
        """
        if len(stale_instances) == 0:
            zslogger.info(f"No stale instances identified, no clean up required.")
            return []

        processed_instances = []
        for instance in stale_instances:
            try:
                zslogger.info(f"Attempting to clean up stale instance {instance}")
                self.zscaler_client.process_data(zs_group_id=instance.ECGroupId, zs_vm_id=instance.VmId)
                zslogger.info(f"Successfully cleaned up stale instance {instance}")
                processed_instances.append(instance)
            except Exception as e:
                zslogger.error(f"Failed to clean up stale instance {instance}. Error: {str(e)}")
        return processed_instances


    def handle_resource_synchronization(self, vmss_names):
        """
        This function is responsible for managing the clean up of stale CCs in the EC Group. A stale CC is
        defined as a CC that exists in the EC Group but does not exist in the VMSS, or whose uuid never
        resolved to a real Azure VmId within the placeholder grace period. The function will:
            - query zscaler cloud to get VMs in EC Group
            - query VMSS to get VMs in VMSS
            - do diff to find stale instances
            - perform clean up on any stale zscaler resources
        """
        # get vms in resource group + organze them based on vmss
        vmss_cache = self.get_vmss_vms(vmss_names=vmss_names)
        
        for vmss_name in vmss_names:
            zslogger.info(f"VMs in VMSS: {vmss_cache[vmss_name]}")

            # get VMs in EC Group
            ec_group_instances, placeholder_stale_instances = self.get_ec_group_vms(vmss_name=vmss_name)

            # check if there are any stale instances in Zscaler EC Group
            stale_instances = self.find_stale_ec_group_instances(
                ec_group_instances=ec_group_instances,
                vmss_instances=vmss_cache[vmss_name]
            )

            # instances stuck with an unresolved uuid past the grace period are stale as well
            if placeholder_stale_instances:
                zslogger.warning(
                    f"Identified {len(placeholder_stale_instances)} instance(s) in VMSS {vmss_name} stuck "
                    f"with an unresolved uuid beyond the {PLACEHOLDER_UUID_GRACE_PERIOD_MIN} min grace "
                    f"period, treating as stale."
                )
            stale_instances.extend(placeholder_stale_instances)

            # clean up stale instances, returning processed instances to help with UTs
            self.clean_up_stale_instances(stale_instances=stale_instances)
