Zscaler Azure Function functionality Release Notes

## Version 1.0.4
**Release Date:** [September 16, 2026]

### Enhancements and Fixes
- Extended the v1.0.1 fix for Cloud Connectors being removed from their Cloud Connector Group while booting up. That fix did not cover every placeholder value reported by Zscaler Cloud, so the issue could still occur.
  - Until a Cloud Connector uploads its cloud-info, Zscaler Cloud reports a placeholder `metaConfig.uuid` of the form `<ecVmId>-4`/`<ecVmId>-6`. Resource Synchronization only skipped an empty uuid or a uuid equal to the ec vm id, so this form was compared against the live Azure VM IDs, never matched, and was treated as stale and deleted.
  - Placeholder uuids are now identified by GUID shape and excluded from the Azure VM ID comparison entirely. They are treated as stale only once the ecVM's own `registerTime` shows the uuid has been unresolved for longer than a grace period.
  - The grace period defaults to 15 minutes and can be overridden with the `PLACEHOLDER_UUID_GRACE_PERIOD_MIN` App Setting.
- Clean up of Cloud Connectors that were scaled in or replaced is unchanged. Records whose uuid is a real Azure VM ID are still removed when that VM no longer exists in the VMSS.

### Other Changes
- No other functional changes in this release.

---

## Version 1.0.3
**Release Date:** [April 23, 2025]

### Security Fixes
- Addressed a vulnerability found in the `urllib3` Python library.
  - Updated `requests` from version **2.32.2** to **2.32.5**.
    - Updated `urllib3` from version **2.4.0** to **2.6.3**.
  - This resolves known security concerns related to various CVE's and notable impreovements which was in v2.4.0.

## version 1.0.2
- Addressed a vulnerability found in the `requests` Python library.
  - Updated `requests` from version **2.29.0** to **2.32.2**.
  - This resolves known security concerns related to HTTP request handling.


### Other Changes
- No other functional changes in this release.

---

## Version 1.0.1

### Enhancements and Fixes
- Added a fix to resolve a bug where Cloud Connectors were being removed from their Cloud Connector Groups in the Zscaler Portal while they were booting up. This issue occured when the Resource Synchronization function was triggered at the same time when the Cloud Connector was booting up.
