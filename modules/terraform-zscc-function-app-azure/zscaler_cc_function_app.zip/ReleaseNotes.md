Zscaler Azure Function functionality Release Notes

## Version 1.0.2
**Release Date:** [April 23, 2025]

### Security Fixes
- Addressed a vulnerability found in the `requests` Python library.
  - Updated `requests` from version **2.29.0** to **2.32.2**.
  - This resolves known security concerns related to HTTP request handling.

### Other Changes
- No other functional changes in this release.

---

## Version 1.0.1

### Enhancements and Fixes
- Added a fix to resolve a bug where Cloud Connectors were being removed from their Cloud Connector Groups in the Zscaler Portal while they were booting up. This issue occured when the Resource Synchronization function was triggered at the same time when the Cloud Connector was booting up.
