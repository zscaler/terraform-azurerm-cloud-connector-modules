"""
Copyright (C) 2007-2023 Zscaler, Inc. All rights reserved.
Unauthorized copying of this file, via any medium is strictly prohibited
Proprietary and confidential
"""
import logging
import os
import time
from logging import Logger
from urllib.parse import urlparse

import requests

# Configure logging
logging.basicConfig(level=logging.INFO)
logger: Logger = logging.getLogger(__name__)

# Create a formatter
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(funcName)s - %(message)s')

# Create a handler and set the formatter
handler = logging.StreamHandler()
handler.setFormatter(formatter)

# Add the handler to the logger
logger.addHandler(handler)


class ZscalerApiClient:
    def __init__(self, api_key, username, password, base_url, ssl_verify_enable=True):
        self.api_key = api_key
        self.username = username
        self.password = password
        self.base_url = base_url
        self.jsessionid = None
        self.ssl_verify_enable = ssl_verify_enable

    @staticmethod
    def obfuscate_api_key(seed: object) -> object:
        now = int(time.time() * 1000)
        n = str(now)[-6:]
        r = str(int(n) >> 1).zfill(6)
        key = ""
        for i in range(0, len(str(n)), 1):
            key += seed[int(str(n)[i])]
        for j in range(0, len(str(r)), 1):
            key += seed[int(str(r)[j]) + 2]

        # logger.info(f"Timestamp: {now}\tKey: {key}")
        return now, key

    def authenticate(self) -> object:
        auth_url = f"{self.base_url}/api/v1/auth"
        timestamp, new_api_key = self.obfuscate_api_key(self.api_key)
        auth_payload = {
            "apiKey": new_api_key,
            "username": self.username,
            "password": self.password,
            "timestamp": timestamp
        }
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

        response = requests.post(auth_url, json=auth_payload, headers=headers, verify=self.ssl_verify_enable)

        if response.status_code == 200:
            self.jsessionid = response.cookies.get('JSESSIONID')
            logger.info("Authentication successful.")
        else:
            logger.error(f"Authentication failed. HTTP status code: {response.status_code}")
            exit()

    def make_api_request(self, url: object, method: object = 'get', payload: object = None) -> object:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Cookie": f"JSESSIONID={self.jsessionid}"
        }
        logger.info(f"method: {method} url: {url}")

        max_retries = 3
        retries = 0
        delay = 1  # initial delay in seconds

        while retries < max_retries:
            try:
                if method == 'get':
                    response = requests.get(url, headers=headers, verify=self.ssl_verify_enable)
                elif method == 'post':
                    response = requests.post(url, json=payload, headers=headers, verify=self.ssl_verify_enable)
                elif method == 'put':
                    response = requests.put(url, headers=headers, verify=self.ssl_verify_enable)
                elif method == 'delete':
                    response = requests.delete(url, headers=headers, verify=self.ssl_verify_enable)
                    if 200 <= response.status_code < 300:
                        logger.info(f"API request successful. HTTP status code: {response.status_code}")
                        return None  # No JSON content to return for the delete method
                else:
                    logger.error("Invalid HTTP method.")
                    return None

                logger.info(f"method: {method} url: {url} http_status_code: {response.status_code}")

                if 200 <= response.status_code < 300:
                    data = response.json()
                    logger.info(f"API request successful. Response: {data}")
                    return data
                else:
                    logger.error(f"API request failed. url: {url} HTTP status code: {response.status_code}")
                    return None

            except requests.exceptions.RequestException as e:
                logger.error(f"Error occurred during API request: {str(e)}")
                if retries == max_retries - 1:
                    logger.error("Maximum number of retries reached.")
                    return None

                # Increase the retry count and calculate the next delay using the backoff strategy
                retries += 1
                delay *= 2  # example of exponential backoff
                logger.info(f"Retry #{retries}. Retrying in {delay} seconds...")
                time.sleep(delay)

    def process_data(self, zs_group_id, zs_vm_id):
        # Step 1: Authenticate and obtain JSESSIONID
        self.authenticate()

        # # Step 2: Use JSESSIONID for further API calls
        # ecgrouplite_url = f"{self.base_url}/api/v1/ecgroup/lite"
        # self.make_api_request(ecgrouplite_url)
        #
        # # Step 3: Read ecvmid
        ecvm_url: str = f"{self.base_url}/api/v1/ecgroup/{zs_group_id}/vm/{zs_vm_id}"
        self.make_api_request(ecvm_url)

        # Step 4: Delete the ecvmid
        self.make_api_request(ecvm_url, method='delete')

        # Step 5: Get ecAdminActivateStatus
        ec_admin_activate_status_url = f"{self.base_url}/api/v1/ecAdminActivateStatus"
        self.make_api_request(ec_admin_activate_status_url)

        # Step 6: Activate using Put
        ec_admin_activate_url: str = f"{self.base_url}/api/v1/ecAdminActivateStatus/activate"
        self.make_api_request(ec_admin_activate_url, method='put')

        # Step 7: Logout using delete
        logout_url = f"{self.base_url}/api/v1/auth"
        self.make_api_request(logout_url, method='delete')


    def get_ec_group_by_name(self, ec_group_name):
        self.authenticate()
        url = f"{self.base_url}/api/v1/ecgroup?name={ec_group_name}"
        response = self.make_api_request(url)
        return response


def main():
    test_zscaler_resource_deletion()


def test_zscaler_resource_deletion():
    from utils.secret_manager import get_secret_value
    cc_url = os.environ['CC_URL']

    secret_name = os.environ['SECRET_NAME']

    # Call the method to retrieve the secret value
    api_key, username, password = get_secret_value(secret_name)

    prov_url = "https://" + cc_url
    parsed_url = urlparse(prov_url)
    base_url = "https://" + parsed_url.netloc
    logger.info(f"Zscaler Cloud url: {base_url}")
    start_time = time.time()
    zscaler_api = ZscalerApiClient(api_key, username, password, base_url)
    # Test data
    zs_group_id: int = 1234
    zs_vm_id = 4567
    zscaler_api.process_data(zs_group_id, zs_vm_id)
    end_time = time.time()
    execution_time = end_time - start_time
    logger.info(f"Time taken: {execution_time} seconds")


if __name__ == "__main__":
    main()
