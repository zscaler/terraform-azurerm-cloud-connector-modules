from datetime import timedelta, datetime, timezone
import time
from pydantic import BaseModel
import os

from azure.mgmt.compute import ComputeManagementClient, models

from lib.zs_logger import zslogger
from constants import (
    CC_AGGR_HEALTH_METRIC_NAME,
    CC_METRIC_NAMESPACE,
    HEALTHY_METRIC_VALUE,
    UNHEALTHY_METRIC_VALUE,
    DEFAULT_HC_DATA_POINTS,
    DEFAULT_HC_UNHEALTHY_THRESHOLD,
    DEFAULT_HC_CONSECUTIVE_UNHEALTHY_THRESHOLD,
    DEFAULT_MAX_TERMINATION_PERCENT,
    DEFAULT_GRACE_PERIOD_TIME_MIN,
    TERMINATION_POLICY_OLDEST,
    TERMINATION_POLICY_NEWEST
)
from azure_utils import AzureClient
from azure_utils import (
    generate_instance_resource_id
)

HC_DATA_POINTS = os.environ.get('HC_DATA_POINTS', DEFAULT_HC_DATA_POINTS)
HC_UNHEALTHY_THRESHOLD = os.environ.get('HC_UNHEALTHY_THRESHOLD', DEFAULT_HC_UNHEALTHY_THRESHOLD)
HC_CONSECUTIVE_UNHEALTHY_THRESHOLD = os.environ.get(
    'HC_CONSECUTIVE_UNHEALTHY_THRESHOLD', DEFAULT_HC_CONSECUTIVE_UNHEALTHY_THRESHOLD
)
GRACE_PERIOD_TIME_MIN = os.environ.get('GRACE_PERIOD_TIME_MIN', DEFAULT_GRACE_PERIOD_TIME_MIN)
MAX_TERMINATION_PERCENT = os.environ.get('MAX_TERMINATION_PERCENT', DEFAULT_MAX_TERMINATION_PERCENT)
if os.environ.get('TERMINATE_UNHEALTHY_INSTANCES', 'true') == 'true':
    TERMINATE_UNHEALTHY_INSTANCES = True
else:
    TERMINATE_UNHEALTHY_INSTANCES = False
VMSS_CONFIG_WAIT_TIME_SEC=5
if os.environ.get('TERMINATION_POLICY', TERMINATION_POLICY_OLDEST) == TERMINATION_POLICY_NEWEST:
    TERMINATION_POLICY = TERMINATION_POLICY_NEWEST
else:
    TERMINATION_POLICY = TERMINATION_POLICY_OLDEST


class InstanceInfo(BaseModel):
    InstanceId: str
    TimeCreated: datetime


class HealthMonitor:
    def __init__(self, subscription_id, managed_identity, resource_group, vmss_name):
        self.subscription_id = subscription_id
        self.managed_identity = managed_identity
        self.resource_group = resource_group
        self.vmss_name = vmss_name

        self.azure_client = None
        self.credentials = None
        self.compute_mgmt_client = None
        self.metrics_query_client = None

        self.termination_list = []


    @classmethod
    def create_health_monitor_instance(cls, subscription_id, managed_identity, resource_group, vmss_name):
        return cls(subscription_id, managed_identity, resource_group, vmss_name)


    def init_azure_client(self, ):
        if self.azure_client is None:
            self.azure_client = AzureClient.create_azure_client_instance(
                subscription_id=self.subscription_id,
                managed_identity=self.managed_identity
            )
            zslogger.info(f"Initialized Azure Client.")


    def sort_metric_values(self, metric_values):
        metric_values = sorted(metric_values, key=lambda x: x['Timestamp'])
        return_val = []
        for item in metric_values:
            return_val.append(item['Value'])
        return return_val


    def get_cc_health_metrics(self, instance_id):
        # init azure client
        self.init_azure_client()

        # generate resource id for instance
        resource_id = generate_instance_resource_id(
            subscription=self.subscription_id,
            resource_group=self.resource_group,
            instance_id=instance_id
        )

        # make call to query for metric values
        response = self.azure_client.query_resource_metrics(
            resource_id=resource_id
        )

        # parse response and generate values list
        values = []
        for metric in response.metrics:
            for time_series_element in metric.timeseries:
                for metric_value in time_series_element.data:
                    values.append({'Value': metric_value.maximum, 'Timestamp': metric_value.timestamp})
                    zslogger.info(f"Value: {metric_value.maximum}, Timestamp: {metric_value.timestamp}")
        return self.sort_metric_values(metric_values=values)


    def has_instance_been_alive_30_min(self, vm_config):
        zslogger.info(f"Instance creation time: {vm_config.time_created}")
        cur_time = datetime.now(timezone.utc)
        zslogger.info(f"Current time: {cur_time}")

        # check to see if time created was more or less than 30 min ago
        instance_alive_time = cur_time - vm_config.time_created
        if instance_alive_time < timedelta(minutes=GRACE_PERIOD_TIME_MIN):
            zslogger.info(f"Instance has not been alive for more than {GRACE_PERIOD_TIME_MIN} min.")
            return False
        zslogger.info(f"Instance has been alive for more than {GRACE_PERIOD_TIME_MIN} min.")
        return True


    def check_grace_period(self, vm_config, metric_values):
        """
        A grace period is implemented to allow a CC to boot up before its health is evaluated and the instance 
        is potentially terminated. The grace period will extend until one of the following events occurs:
            - Instance has been alive for more than 30 minutes
            - Instance has atleast one healthy metric published

        Function should return back True/False to indicate if CC is still in grace period. If CC is out of grace 
        period a list of metric values will be returned indicating metric values that occured after grace period 
        concluded. These values should be used when evaluating health
        
        This metric list response  has the following possibilities:
            1. List of metrics with None or 0 values for 10 samples -> Instance alive for more than 30 min without 
               any healthy metrics.
            2. List of metrics starting with healthy value followed by values preceeding it -> Instance has 
               atleast one healthy metric published.
        """

        healthy_index = -1
        for index in range(len(metric_values)):
            value = metric_values[index]
            if value is not None and value != UNHEALTHY_METRIC_VALUE:
                healthy_index = index
                break

        if len(metric_values) == 0 and self.has_instance_been_alive_30_min(vm_config=vm_config):
            # instance has been alive more more than 30 min and no metrics have been reported, returning list 
            # of unhealthy samples
            return True, [None]*HC_DATA_POINTS
        elif healthy_index == -1 and self.has_instance_been_alive_30_min(vm_config=vm_config):
            # instance has been alive more than 30 min and has no reported healthy metrics, returning list of 
            # unhealthy samples
            return True, metric_values[len(metric_values)-HC_DATA_POINTS:]
        elif healthy_index == -1 and not self.has_instance_been_alive_30_min(vm_config=vm_config):
            # instance has no reported healthy metrics but has not been alive more than 30 min
            return False, []
        elif len(metric_values)-healthy_index <= HC_DATA_POINTS:
            # instance has reported healthy atleast once, returning this metric sample and ones preceeding it
            return True, metric_values[healthy_index:]
        else:
            # instance has reported healthy for a while, returning last 10 samples
            return True, metric_values[len(metric_values)-HC_DATA_POINTS:]


    def determine_cc_health(self, instance_id, metric_values):
        unhealthy_cnt = 0
        consecutive_unhealthy_cnt = 0
        max_consecutive_unhealthy_cnt = 0
        for value in metric_values:
            if value == UNHEALTHY_METRIC_VALUE or value is None:
                unhealthy_cnt += 1
                consecutive_unhealthy_cnt += 1
            else:
                consecutive_unhealthy_cnt = 0
            if max_consecutive_unhealthy_cnt < consecutive_unhealthy_cnt:
                max_consecutive_unhealthy_cnt = consecutive_unhealthy_cnt
        zslogger.info(
            f"Instance {instance_id} has {unhealthy_cnt} unhealthy values and {max_consecutive_unhealthy_cnt} "
            "consecutive unhealthy values."
        )

        if unhealthy_cnt >= HC_UNHEALTHY_THRESHOLD and len(metric_values) >= HC_DATA_POINTS:
            # handles case where unhealthy count is higher than threshold and number of samples surpases needed 
            # amount
            return False
        elif max_consecutive_unhealthy_cnt >= HC_CONSECUTIVE_UNHEALTHY_THRESHOLD:
            # handles case where consecutive unhealthy count is higher than threshold
            return False
        else:
            return True


    def evaluate_cc_health(self, instance_id):
        # init azure client
        self.init_azure_client()

        # get instance information
        vm_config = self.azure_client.get_virtual_machine(resource_group=self.resource_group, instance_id=instance_id)

        # get health metrics
        metric_values = self.get_cc_health_metrics(instance_id=instance_id)
        zslogger.info(f"Metric values for instance {instance_id}: {metric_values}")

        # check if instance is outside of its grace period
        grace_period_complete, metric_values = self.check_grace_period(
            vm_config=vm_config,
            metric_values=metric_values
        )
        zslogger.info(f"Grace period complete: {grace_period_complete}")

        if not grace_period_complete:
            # if grace period is not complete, move on
            return

        zslogger.info(f"Metric values to be evaluated: {metric_values}")
        healthy = self.determine_cc_health(instance_id=instance_id, metric_values=metric_values)
        zslogger.info(f"Instance is healthy: {healthy}")

        # if grace period is complete evaluate health of instance
        if not healthy:
            zslogger.info(f"Instance {instance_id} is unhealthy, adding it to the termination list.")
            instance_info = InstanceInfo(InstanceId=instance_id, TimeCreated=vm_config.time_created)
            self.termination_list.append(instance_info)


    def sort_terminated_instances(self, ):
        """
        Simple insertion sort since this will be an array less than instance list.
        Sorting is done based on the time created and will be ordered based on the termination policy defined.
        """
        if len(self.termination_list) <= 1:
            return
     
        for i in range(1, len(self.termination_list)):
            cur_item = self.termination_list[i]
            j = i-1
            if TERMINATION_POLICY == TERMINATION_POLICY_OLDEST:
                while j >= 0 and cur_item.TimeCreated < self.termination_list[j].TimeCreated:
                    self.termination_list[j+1] = self.termination_list[j]
                    j -= 1
            else:
                while j >= 0 and cur_item.TimeCreated > self.termination_list[j].TimeCreated:
                    self.termination_list[j+1] = self.termination_list[j]
                    j -= 1
            self.termination_list[j+1] = cur_item


    def terminate_instance(self, instance):
        if not TERMINATE_UNHEALTHY_INSTANCES:
            zslogger.info(f"TERMINATE_UNHEALTHY_INSTANCES set to False, not terminating instances.")
            return
        
        # init azure client
        self.init_azure_client()

        # terminate instance
        self.azure_client.terminate_virtual_machine(
            resource_group=self.resource_group,
            vmss_name=self.vmss_name,
            instance_id=instance.InstanceId
        )


    def replace_terminated_instances(self, prev_vmss_config):
        """
        Compares existing VMSS configuration to snapshot taken before terminations. If there is a difference 
        in capacity, update the VMSS with the capacity before the terminations.
        """
        # init azure client
        self.init_azure_client()
        
        # get vmss config
        new_vmss_config = self.azure_client.get_virtual_machine_scale_set(
            resource_group=self.resource_group,
            vmss_name=self.vmss_name
        )
        zslogger.info(f"VMSS Capacity before terminations: {prev_vmss_config.sku.capacity}")
        zslogger.info(f"VMSS Capacity after terminations: {new_vmss_config.sku.capacity}")

        # compare capacities
        if prev_vmss_config.sku.capacity > new_vmss_config.sku.capacity:
            zslogger.info(
                "VMSS capacity has changed, increasing capacity to what was configured before "
                f"terminations: {prev_vmss_config.sku.capacity}"
            )
            new_vmss_config.sku.capacity = prev_vmss_config.sku.capacity
            self.azure_client.update_virtual_machine_scale_set(
                resource_group=self.resource_group,
                vmss_name=self.vmss_name,
                vmss_config=new_vmss_config
            )
        else:
            zslogger.info(f"No change in capacity before and after terminations, no action taken.")
        
        # return the configured capacity
        return new_vmss_config.sku.capacity


    def handle_cc_termination(self, total_instances):
        """
        Function handles terminating instances that have been marked unhealthy. To avoid removing all instances 
        from the VMSS at the same time, we will only be terminating 20% or 1 instance, which ever one is higher. 
        The instance with the most unhealthy samples in the last 10 minutes will be the one chosen for 
        termination.

        One other note is we need to get current VMSS information because when a terminate call is made the 
        desired instance count decreases. To ensure that we replacing any terminated instances we need to 
        perform an update after the terminations to bring up new instances to replace unhealthy ones.
        Workflow is:
            - get vmss info
            - terminate instances
            - sleep for 5 seconds
            - get vmss info again
            - do diff on capacity count in the sku field
            - if its decreased, increase it back and perform an update
            - if it stayed the same we know that we had previously initiated a terminate on this instance and 
              initiated creation of a new one, here the instance is just going through a clean up flow.
        """
        # init azure client
        self.init_azure_client()

        if len(self.termination_list) == 0:
            zslogger.info(f"No instances to terminate on this iteration.")
            return []

        # order instances based on unhealthy_cnt, largest to smallest
        self.sort_terminated_instances()
        zslogger.info(f"Unhealhty instances detected, starting termination process.")

        # deterine how many to terminate based on criteria
        percent_delete = int(total_instances*MAX_TERMINATION_PERCENT)
        if percent_delete < 1:
            percent_delete = 1
        zslogger.info(f"Number of instances that are allowed to be deleted on this iteration: {percent_delete}")

        # get vmss config
        vmss_config = self.azure_client.get_virtual_machine_scale_set(
            resource_group=self.resource_group,
            vmss_name=self.vmss_name
        )

        # iterate through allowed number of terminations and terminate the instances with highest unhealthy
        # counts
        terminated_list = []
        for i in range(percent_delete):
            instance = self.termination_list[i]
            zslogger.info(f"Attempting to terminate {instance.InstanceId}")
            try:
                self.terminate_instance(instance=instance)
            except Exception as e:
                zslogger.error(f"Failed to terminate instance {instance.InstanceId}. Error: {str(e)}")
                continue
            terminated_list.append(instance)

        if len(terminated_list) != 0:
            # sleep to allow desired count to change on VMSS
            time.sleep(VMSS_CONFIG_WAIT_TIME_SEC)
            self.replace_terminated_instances(prev_vmss_config=vmss_config)

        return terminated_list


    def handle_vmss_cc_health(self, ):
        # init azure client
        self.init_azure_client()

        # get instances from vmss
        instance_list = self.azure_client.get_vms_in_vmss(resource_group=self.resource_group, vmss_name=self.vmss_name)

        # iterate through each instance and evaluate health
        for instance in instance_list:
            zslogger.info(f"Attempting to evaluate health of instance {instance}.")
            try:
                self.evaluate_cc_health(instance_id=instance)
            except Exception as e:
                zslogger.error(f"Failed to evaluate health of instance {instance}. Error: {str(e)}")
                continue
            zslogger.info(f"Successfully to evaluated health of instance {instance}.")

        # terminate unhealthy instances
        self.handle_cc_termination(total_instances=len(instance_list))


