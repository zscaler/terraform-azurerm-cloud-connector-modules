from pydantic import BaseModel
import os

from lib.zs_logger import zslogger
from lib.zscaler_client.zscaler_api_client import ZscalerApiClient
from constants import (
    API_KEY_SECRET_NAME,
    USERNAME_SECRET_NAME,
    PASSWORD_SECRET_NAME
)
from azure_utils import AzureClient
from azure_utils import (
    extract_base_url,
    vmss_config_extract_vnet_name,
    generate_ec_group_name
)

VAULT_URL = os.environ.get('VAULT_URL')
CC_URL = os.environ.get('CC_URL')


class ECGroupInstanceInfo(BaseModel):
    VmId: int
    CloudNativeId: str


class ResourceSynchronizer:

    def __init__(self, subscription_id, managed_identity, resource_group, vmss_name):
        self.subscription_id = subscription_id
        self.managed_identity = managed_identity
        self.resource_group = resource_group
        self.vmss_name = vmss_name

        self.azure_client = None
        self.zscaler_client = None

        self.credentials = None
        self.secret_client = None
        self.compute_mgmt_client = None

        self.ec_group_id = None


    @classmethod
    def create_resource_synchronizer_instance(cls, subscription_id, managed_identity, resource_group, vmss_name):
        return cls(subscription_id, managed_identity, resource_group, vmss_name)


    def init_azure_client(self, ):
        if self.azure_client is None:
            self.azure_client = AzureClient.create_azure_client_instance(
                subscription_id=self.subscription_id,
                managed_identity=self.managed_identity
            )
            zslogger.info(f"Initialized Azure Client.")


    def get_azure_secrets(self,):
        # init azure client
        self.init_azure_client()

        if VAULT_URL is None:
            raise Exception(
                "VAULT_URL is not defined as an App Settings for the Function App. Not able to retrieve "
                "secrets to perform operations."
            )

        # make call to get api-key secret
        api_key = self.azure_client.get_secret(vault_url=VAULT_URL, name=API_KEY_SECRET_NAME).value
        # make call to get username secret
        username = self.azure_client.get_secret(vault_url=VAULT_URL, name=USERNAME_SECRET_NAME).value
        # make call to get password secret
        password = self.azure_client.get_secret(vault_url=VAULT_URL, name=PASSWORD_SECRET_NAME).value
        return api_key, username, password


    def init_zscaler_client(self, ):
        """
        When initializing Zscaler Client, it is required the CC_URL ENV Variable is set.
        In this function the secrets will be pulled from Azure Key Vaule and initialize the zscaler client.
        """
        if self.zscaler_client is None:
            # generate base url
            if CC_URL is None:
                raise Exception(
                    "CC_URL is not defined as an App Settings for the Function App. Not able to connect to "
                    "Zscaler Cloud."
                )
            api_key, username, password = self.get_azure_secrets()
            self.zscaler_client = ZscalerApiClient(
                api_key=api_key,
                username=username,
                password=password,
                base_url=extract_base_url(cc_url=CC_URL)
            )
            zslogger.info(f"Initialized Zscaler Client.")


    def get_ec_group_vms(self,):
        """
        Function will initialize a zscaler client using secrets stored in Azure Key Vault. It will then 
        make a list EC Groups call to Zscaler Cloud with query parameter of name=<ec-group-name>. It will 
        then parse the response to return a list of dictionaries containing the VM ID and Cloud Native ID. 
        """
        # init zscaler client
        self.init_zscaler_client()
        # init azure client
        self.init_azure_client()

        # get vmss config to know location and VNet, this will be used for generating ec group name
        vmss_config = self.azure_client.get_virtual_machine_scale_set(
            resource_group=self.resource_group,
            vmss_name=self.vmss_name
        )

        # generate ec group name
        ec_group_name = generate_ec_group_name(
            vnet_name=vmss_config_extract_vnet_name(vmss_config),
            location=vmss_config.location,
            vmss_name=self.vmss_name
        )
        zslogger.info(f"Generated EC Group Name: {ec_group_name}")

        # query EC Group to get list of instances
        zslogger.info(f"Attempting to query EC Group to get list of instances.")
        response = self.zscaler_client.get_ec_group_by_name(ec_group_name=ec_group_name)
        zslogger.info(f"Successfully queried EC Group to get list of instances.")
        zslogger.info(f"Get EC Group Resp: {response}")

        if len(response) == 0:
            zslogger.error(f"EC Group {ec_group_name} does not exist.")
            return []

        # set ec group ID for use in other functions
        self.ec_group_id = response[0]['id']

        # parse response to extract mapping of VM Id to Cloud Native Id
        instances = []
        for item in response[0].get('ecVMs', []):
            cur_item = ECGroupInstanceInfo(
                VmId=item['id'],
                CloudNativeId=item['metaConfig'].get('nativeId', '')
            )
            instances.append(cur_item)
        zslogger.info(f"Identified the following instances in EC Group: {instances}")
        return instances


    def find_stale_ec_group_instances(self, ec_group_instances, vmss_instances):
        """
        Function records any instances that exist in the ec_group_instances list but not in the vmss_instances 
        list.
        """
        stale_instances_list = []
        for ec_group_instance in ec_group_instances:
            found = False
            for vmss_instance in vmss_instances:
                if vmss_instance == ec_group_instance.CloudNativeId:
                    found = True
                    break
            if not found:
                stale_instances_list.append(ec_group_instance)
        zslogger.info(f"Identified the following stale instances in the EC Group: {stale_instances_list}")
        return stale_instances_list


    def clean_up_stale_instances(self, stale_instances):
        """
        Function iterates through the passed in stale instances and makes API calls to remove them from EC Group.
        """
        if len(stale_instances) == 0:
            zslogger.info(f"No stale instances identitied, no clean up required.")
            return []

        processed_instances = []
        for instance in stale_instances:
            try:
                zslogger.info(f"Attempting to clean up stale instance {instance}")
                self.zscaler_client.process_data(zs_group_id=self.ec_group_id, zs_vm_id=instance.VmId)
                zslogger.info(f"Successfully cleaned up stale instance {instance}")
                processed_instances.append(instance)
            except Exception as e:
                zslogger.error(f"Failed to clean up stale instance {instance}. Error: {str(e)}")
        return processed_instances


    def handle_resource_synchronization(self):
        """
        This function is responsible for managing the clean up of stale CCs in the EC Group. A stale CC is
        defined as a CC that exists in the EC Group but does not exist in the VMSS. The function will:
            - query zscaler cloud to get VMs in EC Group
            - query VMSS to get VMs in VMSS
            - do diff to find stale instances
            - perform clean up on any stale zscaler resources
        """
        # init azure client
        self.init_azure_client()
        
        # get VMs in EC Group
        ec_group_instances = self.get_ec_group_vms()

        # get VMs in VMSS
        vmss_instances = self.azure_client.get_vms_in_vmss(resource_group=self.resource_group, vmss_name=self.vmss_name)
        zslogger.info(f"VMs in VMSS: {vmss_instances}")

        # check if there are any stale instances in Zscaler EC Group
        stale_instances = self.find_stale_ec_group_instances(
            ec_group_instances=ec_group_instances,
            vmss_instances=vmss_instances
        )

        # clean up stale instances, returning processed instances to help with UTs
        return self.clean_up_stale_instances(stale_instances=stale_instances)



