import os
import azure.functions as func

from lib.zs_logger import zslogger
from health_monitor import HealthMonitor
from resource_sync import ResourceSynchronizer

app = func.FunctionApp()


def process_health_monitor(myTimer: func.TimerRequest) -> None:
    zslogger.info('Health monitoring triggered.')

    subscription_id = os.environ.get('SUBSCRIPTION_ID')
    managed_identity = os.environ.get('MANAGED_IDENTITY')
    resource_group = os.environ.get('RESOURCE_GROUP')
    vmss_name = os.environ.get('VMSS_NAME')
    if not subscription_id or not managed_identity or not resource_group or not vmss_name:
        zslogger.error(
            f"Missing ENV Varibales. SUBSCRIPTION_ID: {subscription_id}, MANAGED_IDENTITY: {managed_identity}, " 
            f"RESOURCE_GROUP: {resource_group}, VMSS_NAME: {vmss_name}"
        )
        return

    health_mon_obj = HealthMonitor.create_health_monitor_instance(
        subscription_id=subscription_id,
        managed_identity=managed_identity,
        resource_group=resource_group,
        vmss_name=vmss_name
    )
    health_mon_obj.handle_vmss_cc_health()


def process_synchronize_cloud_resources(myTimer: func.TimerRequest) -> None:
    zslogger.info(f"Resource clean up triggered.")

    subscription_id = os.environ.get('SUBSCRIPTION_ID')
    managed_identity = os.environ.get('MANAGED_IDENTITY')
    resource_group = os.environ.get('RESOURCE_GROUP')
    vmss_name = os.environ.get('VMSS_NAME')
    if not subscription_id or not managed_identity or not resource_group or not vmss_name:
        zslogger.error(
            f"Missing ENV Varibales. SUBSCRIPTION_ID: {subscription_id}, MANAGED_IDENTITY: {managed_identity}, " 
            f"RESOURCE_GROUP: {resource_group}, VMSS_NAME: {vmss_name}"
        )
        return

    resource_sync_obj = ResourceSynchronizer.create_resource_synchronizer_instance(
        subscription_id=subscription_id,
        managed_identity=managed_identity,
        resource_group=resource_group,
        vmss_name=vmss_name
    )
    resource_sync_obj.handle_resource_synchronization()


@app.timer_trigger(schedule="0 * * * * *", arg_name="myTimer", run_on_startup=False,
              use_monitor=True) 
def healthMonitor(myTimer: func.TimerRequest) -> None:
    process_health_monitor(myTimer)


@app.timer_trigger(schedule="0 0 * * * *", arg_name="myTimer", run_on_startup=False,
              use_monitor=True) 
def synchronizeCloudResources(myTimer: func.TimerRequest) -> None:
    process_synchronize_cloud_resources(myTimer)


